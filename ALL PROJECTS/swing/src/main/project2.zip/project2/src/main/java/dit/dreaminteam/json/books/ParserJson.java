package dit.dreaminteam.json.books;

import dit.dreaminteam.entities.Book;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Created by dreaminteam on 19.2.15.
 */
public class ParserJson {

    public static void main(String[] args) throws IOException, JSONException {

        ParserJson parserJson = new ParserJson();
        List<Book> books = parserJson.parsJson(JSON_BOOKS);

        System.out.println(books.toString());

    }

    public List<Book> parsJson(String jsonFile) throws IOException, JSONException {

        List<Book> listBooks = new ArrayList<Book>();

        ClassLoader classLoader = getClass().getClassLoader();
        System.out.println(classLoader.getResource("db/books.json").getFile());
        File file = new File(classLoader.getResource("db/books.json").getFile());

        try (FileReader fileReader = new FileReader(new File(JSON_BOOKS))) {

            JSONTokener tokener = new JSONTokener(fileReader);
            JSONObject jsonObject = new JSONObject(tokener);
            JSONArray jsonArray = jsonObject.getJSONArray("books");
            System.out.println(jsonArray.length());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject object = jsonArray.getJSONObject(i);
                Book book = new Book();
                book.name = object.getString("name");
//            book.authors = object.getString("authors");
                book.availability = object.getBoolean("availability");
                book.genre = object.getString("genre");
                book.id = object.getInt("id");
                book.yearOfPublication = object.getInt("publication");
                listBooks.add(book);
            }
        }
        return listBooks;
    }

    private static final String JSON_BOOKS = "/home/dreaminteam/ALL PROJECTS/project2/src/main/resourсes/db/books.json";

}
