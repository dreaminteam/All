package librarian;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by dreaminteam on 3.9.14.
 */
public class Book {

    public Book(String name, int yearOfPublication, String genre, String... authors) {

        this.name = name;
        this.yearOfPublication=yearOfPublication;
        this.genre = genre;
        for (String str : authors) {
            this.authors.add(str);
        }
    }


    @Override
    public String toString() {
        return "id:" + id + " - Name:" + name + "; genre:" + genre +
                "; authors:" + authors.toString() + "; availability:" + availability;
    }

    public int getId() {
        return id;
    }

    public String toWrite(){

        return name+";"+genre+";"+authors.toString()+";"+availability;
    }

    private int id = index++;
    public String genre;
    public String name;
    public int yearOfPublication;
    public boolean availability = true;
    public Set<String> authors = new HashSet();

    /*
    public genres genre;
    enum genres {
         DETECTIVE, NOVEL, FANTASTIC, FANTASY, PSYCHOLOGICAL, MYSTICISM, HORROR, HISTORICAL, HUMOR,
         PHILOSOPHY, SCIENCE, ACTION, CHILDREN
     }
     */
    public static int index = 0;
}
