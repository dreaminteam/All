package librarian;

/**
 * Created by dreaminteam on 28.10.14.
 */
public class CardInformationReader {
}
