package librarian;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by dreaminteam on 2.10.14.
 */
public class Author {

    public Author(String ownName, String surName, String dateOfBirth) {
        this.ownName = ownName;
        this.surName = surName;
        this.dateOfBirth = dateOfBirth;
    }

    public String toWrite(){
        return ownName+";"+surName+";"+dateOfBirth;
    }

    public int getId() {
        return id;
    }

    public String ownName;
    public String surName;
    public String dateOfBirth;
    private int id = index++;

    public static int index = 0;

}
