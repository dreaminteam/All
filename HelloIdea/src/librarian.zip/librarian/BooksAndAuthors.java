package librarian;

/**
 * Created by dreaminteam on 13.11.14.
 */
public class BooksAndAuthors {

    public BooksAndAuthors(int idAuthor, int idBook) {
        this.idAuthor = idAuthor;
        this.idBook = idBook;
    }

    public int idAuthor;
    public int idBook;

}
