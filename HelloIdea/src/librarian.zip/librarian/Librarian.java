package librarian;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * Created by dreaminteam on 3.9.14.
 */
public class Librarian {

    public static void main(String[] args) throws FileNotFoundException {

        DataBooks dataBooks = new DataBooks();
        DataReaders dataReaders=new DataReaders();

        Map<Integer, Book> books = dataBooks.init("/home/dreaminteam/IdeaProjects/HelloIdea/src/librarian/data_books.txt");

        books.put(Book.index, new Book("Harry",2012, "detective", "Horstman"));

        books.get(3).availability = false;

        dataBooks.write("/home/dreaminteam/IdeaProjects/HelloIdea/src/librarian/bookData.txt",books);

        Map<Integer,Reader> readers=dataReaders.init("/home/dreaminteam/IdeaProjects/HelloIdea/src/librarian/data_readers.txt");
        readers.put(Reader.index,new Reader("Kolia","Petrov","KH 1148305","Zaharova 5","7665594"));

        dataReaders.write("/home/dreaminteam/IdeaProjects/HelloIdea/src/librarian/readersData.txt",readers);

    }
   // public void
}
